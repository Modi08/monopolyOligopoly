import functions_framework as ff
from google.cloud import firestore
from firebase_functions import https_fn
from firebase_admin import initialize_app

initialize_app()

@https_fn.on_call(enforce_app_check=True)
def main(req: https_fn.CallableRequest) -> dict:
    db = firestore.Client(database="oligarch-games")
    
    request = req.data
    gameId = request['gameId'].strip()
    username = request['username']
    
    docRef = db.collection("games").document(gameId)
    doc = docRef.get()

    if (doc.exists):
        docRef.update({
            username: {
                "cash": 5000,
                "propertiesOwnershipShares": {},
                "propertiesVotershare": {},
                "position": 0,
                "inJail": False,
                "jailTurns": 0,
                "activeLoans": {},
            }
        })
        return ("Successfully joined the game.", 200)
    else:
        return ("Game ID does not exist.", 400)
        