import functions_framework as ff
from google.cloud import firestore
from firebase_functions import https_fn
from firebase_admin import initialize_app

initialize_app()

@https_fn.on_call(enforce_app_check=True)
def main(req: https_fn.CallableRequest) -> dict:
    db = firestore.Client(database="oligarch-games")
    
    request_json = req.data
    username = request_json['username']
    
    docs = db.collection("games").stream()
    gameIds = [int(doc.id) for doc in docs]
    gameIds.sort()

    newGameId = gameIds[-1] + 1 if len(gameIds) > 0 else 1
    docRef = db.collection("games").document(str(newGameId))
    docRef.set({username: {
                "cash": 5000,
                "propertiesOwnershipShares": {},
                "propertiesVotershare": {},
                "position": 0,
                "inJail": False,
                "jailTurns": 0,
                "activeLoans": {},
            }})
    return ("Successfully created the game.", 200, newGameId)
        